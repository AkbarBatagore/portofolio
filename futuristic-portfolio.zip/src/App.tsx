import React, { useState, useEffect, useRef } from 'react';
import { 
  Github, 
  Mail, 
  Volume2, 
  VolumeX, 
  Terminal as TerminalIcon, 
  Settings, 
  Plus, 
  Trash2, 
  Edit3, 
  Save, 
  Check, 
  Menu, 
  X, 
  ExternalLink, 
  RefreshCw, 
  Code, 
  Sparkles, 
  Send, 
  Database, 
  Compass, 
  Sliders, 
  FileText, 
  Instagram,
  Compass as PinterestIcon,
  Play
} from 'lucide-react';

// Interfaces
interface Project {
  id: string;
  title: string;
  description: string;
  tags: string[];
  link: string;
  accent: 'cyan' | 'purple' | 'emerald' | 'amber' | 'rose';
  index: string;
}

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'system' | 'action' | 'audio' | 'success' | 'warning';
}

const DEFAULT_PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Cyber-Link Interface',
    description: 'Dashboard blockchain kustom untuk pemantauan aset real-time dan visualisasi data neural.',
    tags: ['React', 'Three.js', 'Web3'],
    link: 'https://github.com/AkbarBatagore',
    accent: 'cyan',
    index: '01'
  },
  {
    id: '2',
    title: 'Zenon Cloud OS',
    description: 'Desain sistem operasi minimalis untuk perangkat komputasi wearable generasi masa depan.',
    tags: ['Next.js', 'Framer', 'Rust'],
    link: 'https://github.com/AkbarBatagore',
    accent: 'purple',
    index: '02'
  },
  {
    id: '3',
    title: 'Void Marketplace',
    description: 'Hub e-commerce terdesentralisasi dengan protokol transaksi latensi ultra-rendah.',
    tags: ['Solidity', 'Rust', 'Web3'],
    link: 'https://github.com/AkbarBatagore',
    accent: 'emerald',
    index: '03'
  },
  {
    id: '4',
    title: 'Aura Media Engine',
    description: 'Platform audio generatif menggunakan analisis spektral untuk menyinkronkan visual real-time.',
    tags: ['Python', 'WebGL', 'AudioAPI'],
    link: 'https://github.com/AkbarBatagore',
    accent: 'amber',
    index: '04'
  }
];

const SKILLS = [
  { name: 'Frontend Architecture', level: 92, category: 'development' },
  { name: 'React / Next.js Frameworks', level: 95, category: 'development' },
  { name: 'TypeScript & Typings', level: 88, category: 'development' },
  { name: 'Tailwind CSS / UI Systems', level: 96, category: 'creative' },
  { name: 'Framer & Web Animations', level: 85, category: 'creative' },
  { name: 'Smart Contract / Solidity', level: 70, category: 'engineering' },
  { name: 'Rust Core Development', level: 75, category: 'engineering' },
  { name: 'AI Engineering & Prompting', level: 90, category: 'engineering' }
];

export default function App() {
  // Theme & Sound Config
  const [accentColor, setAccentColor] = useState<'cyan' | 'purple' | 'emerald' | 'amber' | 'rose'>('cyan');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [digitalTime, setDigitalTime] = useState<string>('00:00:00');
  
  // Projects state (Persisted in localStorage)
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem('reonzy_projects');
      return saved ? JSON.parse(saved) : DEFAULT_PROJECTS;
    } catch {
      return DEFAULT_PROJECTS;
    }
  });

  // Terminal Logs State
  const [logs, setLogs] = useState<LogEntry[]>([]);

  // Navigation / UI States
  const [activeSection, setActiveSection] = useState<string>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);
  const [filterTag, setFilterTag] = useState<string>('All');
  
  // Interactive Sound Synthesizer Node Handler
  const audioContextRef = useRef<AudioContext | null>(null);

  // Form State for Adding / Editing Projects
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [formData, setFormData] = useState<Partial<Project>>({
    title: '',
    description: '',
    tags: [],
    link: '',
    accent: 'cyan'
  });
  const [formTagsString, setFormTagsString] = useState<string>('');

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  // Initialize synth helper
  const triggerSynth = (type: 'click' | 'success' | 'hover' | 'boot' | 'delete' | 'warning') => {
    if (isMuted) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      
      const now = ctx.currentTime;
      
      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.12);
        gainNode.gain.setValueAtTime(0.06, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.start(now);
        osc.stop(now + 0.12);
      } else if (type === 'hover') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1050, now);
        gainNode.gain.setValueAtTime(0.015, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'success') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.07); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.14); // G5
        osc.frequency.exponentialRampToValueAtTime(1046.50, now + 0.22); // C6
        gainNode.gain.setValueAtTime(0.06, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'delete') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(350, now);
        osc.frequency.linearRampToValueAtTime(120, now + 0.22);
        gainNode.gain.setValueAtTime(0.05, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
      } else if (type === 'warning') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.setValueAtTime(180, now + 0.1);
        gainNode.gain.setValueAtTime(0.08, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      } else if (type === 'boot') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(180, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.4);
        gainNode.gain.setValueAtTime(0.04, now);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
      }
    } catch {
      // Audio fallback
    }
  };

  // Add system event log
  const pushLog = (message: string, type: 'system' | 'action' | 'audio' | 'success' | 'warning' = 'action') => {
    const time = new Date();
    const ts = `${time.toTimeString().split(' ')[0]}.${String(time.getMilliseconds()).padStart(3, '0')}`;
    const newEntry: LogEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: ts,
      message,
      type
    };
    setLogs(prev => [newEntry, ...prev.slice(0, 39)]);
  };

  // Persist projects inside storage when changed
  useEffect(() => {
    localStorage.setItem('reonzy_projects', JSON.stringify(projects));
  }, [projects]);

  // Digital Clock and Boot Sequences
  useEffect(() => {
    // Initial clock ticks
    const updateTime = () => {
      const now = new Date();
      setDigitalTime(now.toTimeString().split(' ')[0]);
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);

    // Boot Terminal Messages
    pushLog("INITIALIZING NEURAL NET V4.2...", "system");
    pushLog("AUTHENTICATING LOCALHOST SESSION...", "system");
    pushLog("REONZY OS BOOT_SEQUENCE: COMPLETE.", "success");
    pushLog("SOCIAL PLATFORMS PARSED: EMAIL, TIKTOK, INSTAGRAM, PINTEREST", "system");
    pushLog("READY FOR OPERATIONS.", "success");

    triggerSynth('boot');

    return () => clearInterval(interval);
  }, []);

  // Sync Tag Filters
  const allTags = ['All', ...Array.from(new Set(projects.flatMap(p => p.tags)))];

  // Accent Styles Class Map
  const accentBorderColors = {
    cyan: 'border-cyan-500/30 hover:border-cyan-400 group-hover:border-cyan-400',
    purple: 'border-fuchsia-500/30 hover:border-fuchsia-400 group-hover:border-fuchsia-400',
    emerald: 'border-emerald-500/30 hover:border-emerald-400 group-hover:border-emerald-400',
    amber: 'border-amber-500/30 hover:border-amber-400 group-hover:border-amber-400',
    rose: 'border-rose-500/30 hover:border-rose-400 group-hover:border-rose-400'
  };

  const accentTextColors = {
    cyan: 'text-cyan-400',
    purple: 'text-fuchsia-400',
    emerald: 'text-emerald-400',
    amber: 'text-amber-400',
    rose: 'text-rose-400'
  };

  const accentBgColors = {
    cyan: 'bg-cyan-500',
    purple: 'bg-fuchsia-500',
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
    rose: 'bg-rose-500'
  };

  const currentThemeHex = {
    cyan: '#06b6d4',
    purple: '#d946ef',
    emerald: '#10b981',
    amber: '#f59e0b',
    rose: '#f43f5e'
  }[accentColor];

  // Smooth Scroll Anchor Function
  const scrollToAnchor = (id: string) => {
    triggerSynth('click');
    setActiveSection(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      pushLog(`NAVIGATED TO SEC: [${id.toUpperCase()}]`, 'action');
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Create or Update Project
  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.description) {
      pushLog("FORM ERROR: Missing Title or Description", "warning");
      triggerSynth('warning');
      return;
    }

    const tagsArray = formTagsString
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    if (editingProject) {
      // Update
      setProjects(prev => prev.map(p => {
        if (p.id === editingProject.id) {
          return {
            ...p,
            title: formData.title || '',
            description: formData.description || '',
            tags: tagsArray,
            link: formData.link || 'https://github.com/AkbarBatagore',
            accent: formData.accent || 'cyan'
          };
        }
        return p;
      }));
      pushLog(`UPDATED PROJECT: [${formData.title}]`, 'success');
    } else {
      // Create new
      const nextIndex = String(projects.length + 1).padStart(2, '0');
      const newProj: Project = {
        id: Math.random().toString(36).substring(2, 9),
        title: formData.title,
        description: formData.description,
        tags: tagsArray,
        link: formData.link || 'https://github.com/AkbarBatagore',
        accent: formData.accent || 'cyan',
        index: nextIndex
      };
      setProjects(prev => [...prev, newProj]);
      pushLog(`ADDED NEW PROJECT: [${formData.title}]`, 'success');
    }

    // Reset Form
    setEditingProject(null);
    setFormData({ title: '', description: '', tags: [], link: '', accent: 'cyan' });
    setFormTagsString('');
    setShowConfigModal(false);
    triggerSynth('success');
  };

  // Edit Initiator
  const startEdit = (proj: Project) => {
    triggerSynth('click');
    setEditingProject(proj);
    setFormData(proj);
    setFormTagsString(proj.tags.join(', '));
    setShowConfigModal(true);
    pushLog(`TERMINAL INPUT: Editing [${proj.title}]`, 'action');
  };

  // Delete Initiator
  const handleDeleteProject = (id: string, name: string) => {
    triggerSynth('delete');
    setProjects(prev => prev.filter(p => p.id !== id));
    pushLog(`DELETED PROJECT ID: [${name}]`, 'warning');
  };

  // Reset to default projects
  const handleResetProjects = () => {
    triggerSynth('warning');
    if (window.confirm("Kembalikan daftar proyek ke default desain?")) {
      setProjects(DEFAULT_PROJECTS);
      pushLog("RESTORED DEFAULT CASE STUDIES", "system");
      triggerSynth('success');
    }
  };

  // Handle Contact Submit
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      pushLog("CONTACT WARNING: Field Kosong", "warning");
      triggerSynth('warning');
      return;
    }

    setIsSending(true);
    triggerSynth('click');
    pushLog(`TRANSMITTING MESSAGE: [${contactForm.subject || 'Inquiry'}]`, 'action');

    // Simulate cyber network sending transmission
    setTimeout(() => {
      setIsSending(false);
      setSendSuccess(true);
      pushLog("MESSAGE TRANSMITTED SECURELY TO REONZY.AKBAR@GMAIL.COM", "success");
      triggerSynth('success');
      
      // Keep state clean
      setContactForm({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setSendSuccess(false), 5000);
    }, 1500);
  };

  // Export config to clipboard
  const exportConfig = () => {
    triggerSynth('success');
    navigator.clipboard.writeText(JSON.stringify(projects, null, 2));
    pushLog("CONFIG COPIED TO SYSTEM CLIPBOARD", "success");
    alert("Daftar project disalin sebagai JSON! Anda dapat menyimpannya untuk backup.");
  };

  // Import config from prompt
  const importConfig = () => {
    triggerSynth('click');
    const pasted = prompt("Tempel kode JSON backup portofolio proyek Anda di sini:");
    if (!pasted) return;
    try {
      const parsed = JSON.parse(pasted);
      if (Array.isArray(parsed)) {
        setProjects(parsed);
        pushLog("IMPORTED NEW CONFIGURATION DATA", "success");
        triggerSynth('success');
      } else {
        throw new Error("Bukan array valid");
      }
    } catch {
      triggerSynth('warning');
      pushLog("IMPORT FAILED: Format JSON tidak valid", "warning");
      alert("Gagal mengimpor. Pastikan format JSON sesuai.");
    }
  };

  // Filter projects list
  const filteredProjects = projects.filter(p => {
    if (filterTag === 'All') return true;
    return p.tags.includes(filterTag);
  });

  return (
    <div id="app" className="min-h-screen bg-[#050505] text-[#e0e0e0] font-sans relative flex flex-col overflow-x-hidden scanline cyber-grid selection:bg-cyan-500/35 selection:text-white">
      
      {/* Background Ambience Orbs */}
      <div className="absolute top-1/4 left-1/4 w-[40vw] h-[40vw] bg-cyan-500/5 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
      <div className="absolute bottom-1/3 right-10 w-[35vw] h-[35vw] bg-fuchsia-500/5 rounded-full blur-[140px] pointer-events-none"></div>

      {/* FIXED HEADER NAVIGATION */}
      <header className="sticky top-0 z-40 bg-[#050505]/85 backdrop-blur-md border-b border-white/10 px-6 py-4 md:px-12 flex items-center justify-between transition-all duration-300">
        
        {/* Brand Logo & Title */}
        <div 
          onClick={() => scrollToAnchor('home')}
          className="flex items-center gap-3 cursor-pointer group"
          onMouseEnter={() => triggerSynth('hover')}
        >
          <div 
            className="w-8 h-8 rounded-sm rotate-45 flex items-center justify-center transition-all duration-300 border"
            style={{ 
              borderColor: currentThemeHex, 
              boxShadow: `0 0 10px ${currentThemeHex}33`
            }}
          >
            <span className="text-white font-bold -rotate-45 text-xs tracking-wider">A</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold tracking-[0.3em] uppercase group-hover:text-white transition-colors">
              AKBAR <span style={{ color: currentThemeHex }}>BATAGORE</span>
            </span>
            <span className="text-[8px] text-white/30 tracking-widest uppercase">System Portofolio</span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex gap-8 text-[10px] uppercase tracking-[0.2em] font-semibold items-center">
          <button 
            onClick={() => scrollToAnchor('home')} 
            className={`transition-all duration-300 ${activeSection === 'home' ? 'text-white border-b-2 pb-1' : 'text-white/50 hover:text-white'}`}
            style={activeSection === 'home' ? { borderBottomColor: currentThemeHex } : {}}
            onMouseEnter={() => triggerSynth('hover')}
          >
            Terminal Home
          </button>
          <button 
            onClick={() => scrollToAnchor('projects')} 
            className={`transition-all duration-300 ${activeSection === 'projects' ? 'text-white border-b-2 pb-1' : 'text-white/50 hover:text-white'}`}
            style={activeSection === 'projects' ? { borderBottomColor: currentThemeHex } : {}}
            onMouseEnter={() => triggerSynth('hover')}
          >
            Selected Work
          </button>
          <button 
            onClick={() => scrollToAnchor('skills')} 
            className={`transition-all duration-300 ${activeSection === 'skills' ? 'text-white border-b-2 pb-1' : 'text-white/50 hover:text-white'}`}
            style={activeSection === 'skills' ? { borderBottomColor: currentThemeHex } : {}}
            onMouseEnter={() => triggerSynth('hover')}
          >
            Skills Matrix
          </button>
          <button 
            onClick={() => scrollToAnchor('contact')} 
            className={`transition-all duration-300 ${activeSection === 'contact' ? 'text-white border-b-2 pb-1' : 'text-white/50 hover:text-white'}`}
            style={activeSection === 'contact' ? { borderBottomColor: currentThemeHex } : {}}
            onMouseEnter={() => triggerSynth('hover')}
          >
            Contact
          </button>
        </nav>

        {/* Status System Metrics (Sound, Theme Hue, Local Clock) */}
        <div className="flex items-center gap-4">
          
          {/* Accent Color quick change */}
          <div className="hidden lg:flex items-center gap-1.5 border border-white/10 px-2.5 py-1 rounded bg-black/40">
            <span className="text-[8px] uppercase tracking-wider text-white/40 mr-1">Hue:</span>
            {(['cyan', 'purple', 'emerald', 'amber', 'rose'] as const).map((c) => (
              <button
                key={c}
                onClick={() => {
                  setAccentColor(c);
                  triggerSynth('click');
                  pushLog(`THEME SCHEME CONFIGURED TO: ${c.toUpperCase()}`, 'system');
                }}
                className={`w-3.5 h-3.5 rounded-full border transition-all ${
                  accentColor === c ? 'scale-125 border-white ring-1 ring-cyan-500/50' : 'border-transparent opacity-60 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: 
                    c === 'cyan' ? '#06b6d4' : 
                    c === 'purple' ? '#d946ef' : 
                    c === 'emerald' ? '#10b981' : 
                    c === 'amber' ? '#f59e0b' : '#f43f5e'
                }}
                title={`Ganti tema aksen ke ${c}`}
              />
            ))}
          </div>

          {/* Time indicator */}
          <div className="hidden sm:block text-[11px] font-mono tracking-widest text-white/50 bg-black/50 border border-white/10 px-3 py-1 rounded">
            SYS_TIME: <span style={{ color: currentThemeHex }} className="font-bold">{digitalTime}</span>
          </div>

          {/* Audio toggle button */}
          <button 
            onClick={() => {
              const nextMute = !isMuted;
              setIsMuted(nextMute);
              if (!nextMute) {
                setTimeout(() => triggerSynth('click'), 100);
              }
              pushLog(`AUDIO FEEDBACK STATE: ${nextMute ? 'MUTED' : 'ACTIVE'}`, 'audio');
            }}
            className="p-1.5 rounded border border-white/10 bg-black/40 text-white/60 hover:text-white hover:border-white/20 transition-all"
            title={isMuted ? "Aktifkan Suara" : "Bisukan Suara"}
          >
            {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} className="animate-pulse" />}
          </button>

          {/* Mobile hamburger menu */}
          <button 
            onClick={() => {
              triggerSynth('click');
              setMobileMenuOpen(!mobileMenuOpen);
            }}
            className="md:hidden p-1.5 rounded border border-white/10 bg-black/40 text-white/60 hover:text-white transition-all"
          >
            {mobileMenuOpen ? <X size={16} /> : <Menu size={16} />}
          </button>

        </div>

      </header>

      {/* MOBILE NAV DRAWER */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed top-[69px] left-0 w-full bg-[#050505]/95 border-b border-white/15 z-30 p-6 flex flex-col gap-5 text-sm uppercase tracking-[0.2em] font-medium backdrop-blur-xl animate-fadeIn">
          
          <div className="flex justify-between items-center pb-2 border-b border-white/5">
            <span className="text-[10px] text-white/30 tracking-[0.3em]">NAVIGASI</span>
            <div className="flex items-center gap-1.5">
              {(['cyan', 'purple', 'emerald', 'amber', 'rose'] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setAccentColor(c);
                    triggerSynth('click');
                  }}
                  className={`w-3 h-3 rounded-full ${accentColor === c ? 'ring-2 ring-white scale-110' : ''}`}
                  style={{
                    backgroundColor: 
                      c === 'cyan' ? '#06b6d4' : 
                      c === 'purple' ? '#d946ef' : 
                      c === 'emerald' ? '#10b981' : 
                      c === 'amber' ? '#f59e0b' : '#f43f5e'
                  }}
                />
              ))}
            </div>
          </div>

          <button 
            onClick={() => scrollToAnchor('home')}
            className={`text-left py-2 flex justify-between items-center ${activeSection === 'home' ? 'text-white' : 'text-white/50'}`}
          >
            <span>01 // HOME</span>
            <span className="text-xs text-cyan-400">►</span>
          </button>
          <button 
            onClick={() => scrollToAnchor('projects')}
            className={`text-left py-2 flex justify-between items-center ${activeSection === 'projects' ? 'text-white' : 'text-white/50'}`}
          >
            <span>02 // SELECTED WORK</span>
            <span className="text-xs text-cyan-400">►</span>
          </button>
          <button 
            onClick={() => scrollToAnchor('skills')}
            className={`text-left py-2 flex justify-between items-center ${activeSection === 'skills' ? 'text-white' : 'text-white/50'}`}
          >
            <span>03 // SKILLS MATRIX</span>
            <span className="text-xs text-cyan-400">►</span>
          </button>
          <button 
            onClick={() => scrollToAnchor('contact')}
            className={`text-left py-2 flex justify-between items-center ${activeSection === 'contact' ? 'text-white' : 'text-white/50'}`}
          >
            <span>04 // CONTACT INTERFACE</span>
            <span className="text-xs text-cyan-400">►</span>
          </button>

          <div className="pt-4 border-t border-white/5 text-[9px] text-white/30 font-mono text-center">
            SYS_TIME: {digitalTime} // SECURITY SECURE
          </div>
        </div>
      )}

      {/* CORE WORKSPACE / WRAPPER */}
      <div className="w-full max-w-[1400px] mx-auto flex-1 flex flex-col md:flex-row border-x border-white/10 min-h-[calc(100vh-69px)]">
        
        {/* LEFT COLUMN: THE STATIONARY PROFILE PANEL */}
        <aside id="home" className="w-full md:w-[38%] border-b md:border-b-0 md:border-r border-white/10 p-6 md:p-12 flex flex-col justify-between gap-12 bg-black/20">
          
          {/* Header Profile Info */}
          <div className="space-y-8">
            
            {/* Pulsing visual photo avatar */}
            <div className="relative w-44 h-44 mb-6 group mx-auto md:mx-0">
              
              {/* Spinning visual borders */}
              <div 
                className="absolute inset-0 border rounded-full animate-spin pointer-events-none" 
                style={{ 
                  animationDuration: '15s',
                  borderColor: `${currentThemeHex}33`,
                  borderTopColor: currentThemeHex
                }}
              ></div>
              <div className="absolute inset-2 border border-dashed border-white/10 rounded-full"></div>
              
              {/* Glowing Ambient Glow */}
              <div 
                className="absolute inset-0 rounded-full filter blur-md transition-all duration-300 opacity-30 group-hover:opacity-70"
                style={{ backgroundColor: currentThemeHex }}
              ></div>

              {/* Real Profile Image */}
              <img 
                src="https://github.com/AkbarBatagore.png" 
                className="w-full h-full object-cover rounded-full border-2 border-white/20 grayscale group-hover:grayscale-0 group-hover:border-white/50 transition-all duration-500 relative z-10" 
                alt="Akbar Batagore Profile Avatar"
                onError={(e) => {
                  // Fallback if avatar fails loading
                  (e.target as HTMLImageElement).src = 'https://avatars.githubusercontent.com/u/9919?v=4';
                }}
              />
              
              {/* Active Now Status badge */}
              <div className="absolute -bottom-2 -right-1 bg-[#050505] border border-white/10 px-3 py-1 text-[9px] uppercase tracking-widest text-emerald-400 font-mono flex items-center gap-1.5 rounded-sm z-20 shadow-lg">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>
                ACTIVE_NOW
              </div>

            </div>

            {/* Profile Intro Texts */}
            <div className="text-center md:text-left">
              <h1 className="text-4xl md:text-5xl font-light leading-tight tracking-tight mb-4 text-white">
                REONZY <br className="hidden md:block"/>
                <span 
                  className="italic font-bold tracking-widest transition-all duration-300"
                  style={{ color: currentThemeHex }}
                >
                  AKBAR
                </span>
              </h1>
              
              <div className="h-0.5 w-16 mb-4 rounded" style={{ backgroundColor: currentThemeHex }}></div>
              
              <p className="text-white/60 text-xs md:text-sm leading-relaxed max-w-sm font-light">
                Membangun pengalaman digital masa depan yang sangat responsif, presisi tinggi, dan kaya visual melalui integrasi visual mutakhir serta rekayasa desain web.
              </p>
            </div>

          </div>

          {/* Social Media Grid */}
          <div className="space-y-4">
            <div className="text-[9px] text-white/30 uppercase tracking-[0.3em] font-bold text-center md:text-left">
              SOCIALS & CHANNELS
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              
              {/* Email contact */}
              <a 
                href="mailto:reonzy.akbar@gmail.com" 
                onClick={() => {
                  triggerSynth('click');
                  pushLog("SOCIAL ENGAGEMENT: Email Mailto triggered", "action");
                }}
                className="flex items-center gap-2 text-[10px] font-mono hover:text-white border border-white/5 p-3 rounded bg-white/[0.01] hover:bg-white/[0.03] transition-all group"
              >
                <Mail size={13} style={{ color: currentThemeHex }} className="group-hover:scale-110 transition-transform" />
                <div className="flex flex-col">
                  <span className="text-[8px] text-white/40">EMAIL</span>
                  <span className="truncate">reonzy.akbar</span>
                </div>
              </a>

              {/* TikTok */}
              <a 
                href="https://www.tiktok.com/@reonzy33" 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => {
                  triggerSynth('click');
                  pushLog("SOCIAL ENGAGEMENT: Redirecting to TikTok @reonzy33", "action");
                }}
                className="flex items-center gap-2 text-[10px] font-mono hover:text-white border border-white/5 p-3 rounded bg-white/[0.01] hover:bg-white/[0.03] transition-all group"
              >
                <Play size={13} style={{ color: currentThemeHex }} className="group-hover:scale-110 transition-transform" />
                <div className="flex flex-col">
                  <span className="text-[8px] text-white/40">TIKTOK</span>
                  <span>@reonzy33</span>
                </div>
              </a>

              {/* Instagram */}
              <a 
                href="https://www.instagram.com/reonzyyx" 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => {
                  triggerSynth('click');
                  pushLog("SOCIAL ENGAGEMENT: Redirecting to Instagram @reonzyyx", "action");
                }}
                className="flex items-center gap-2 text-[10px] font-mono hover:text-white border border-white/5 p-3 rounded bg-white/[0.01] hover:bg-white/[0.03] transition-all group"
              >
                <Instagram size={13} style={{ color: currentThemeHex }} className="group-hover:scale-110 transition-transform" />
                <div className="flex flex-col">
                  <span className="text-[8px] text-white/40">INSTAGRAM</span>
                  <span>reonzyyx</span>
                </div>
              </a>

              {/* Pinterest */}
              <a 
                href="https://www.pinterest.com/reonzyyx" 
                target="_blank" 
                rel="noopener noreferrer"
                onClick={() => {
                  triggerSynth('click');
                  pushLog("SOCIAL ENGAGEMENT: Redirecting to Pinterest @reonzyyx", "action");
                }}
                className="flex items-center gap-2 text-[10px] font-mono hover:text-white border border-white/5 p-3 rounded bg-white/[0.01] hover:bg-white/[0.03] transition-all group"
              >
                <PinterestIcon size={13} style={{ color: currentThemeHex }} className="group-hover:scale-110 transition-transform" />
                <div className="flex flex-col">
                  <span className="text-[8px] text-white/40">PINTEREST</span>
                  <span>@reonzyyx</span>
                </div>
              </a>

            </div>
          </div>

          {/* FUTURISTIC TERMINAL LOGS */}
          <div className="hidden lg:flex flex-col border border-white/10 rounded bg-[#020202]/90 p-4 font-mono text-[9px] h-44 relative overflow-hidden">
            
            {/* Header console bar */}
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/5">
              <div className="flex items-center gap-1.5">
                <TerminalIcon size={11} style={{ color: currentThemeHex }} />
                <span className="text-white/40 tracking-widest font-bold">REONZY_SYSTEM_CONSOLE v2.1</span>
              </div>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            </div>

            {/* Scrollable Log Lines */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
              {logs.map((log) => {
                let colorClass = 'text-white/40';
                if (log.type === 'system') colorClass = 'text-cyan-500/80';
                if (log.type === 'success') colorClass = 'text-emerald-400';
                if (log.type === 'warning') colorClass = 'text-amber-500';
                if (log.type === 'audio') colorClass = 'text-fuchsia-400/80';

                return (
                  <div key={log.id} className="leading-relaxed hover:bg-white/5 px-1 py-0.5 rounded transition-all">
                    <span className="text-white/20 select-none mr-1.5">[{log.timestamp}]</span>
                    <span className={`${colorClass}`}>{log.message}</span>
                  </div>
                );
              })}
            </div>

            <div className="absolute bottom-1 right-2 text-white/10 select-none">SECURE_NODE</div>

          </div>

        </aside>

        {/* RIGHT COLUMN: MAIN CONTENT CHANNELS */}
        <main className="flex-1 flex flex-col bg-[#070707] overflow-y-auto">
          
          {/* SECTION: SELECTED PROJECTS */}
          <section id="projects" className="p-6 md:p-12 border-b border-white/10 relative">
            
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/[0.01] border-b border-l border-white/5 pointer-events-none"></div>

            {/* Title / Header */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles size={12} style={{ color: currentThemeHex, animationDuration: '6s' }} className="animate-spin" />
                  <span className="text-[10px] tracking-[0.4em] uppercase font-bold text-white/40">OPERATIONAL CASE STUDIES</span>
                </div>
                <h2 className="text-3xl font-light tracking-wide text-white">
                  Karya <span className="font-bold">Pilihan</span>
                </h2>
              </div>

              {/* Tag filters slider */}
              <div className="flex flex-wrap gap-1.5">
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      setFilterTag(tag);
                      triggerSynth('click');
                      pushLog(`FILTERING BY CATEGORY: [${(tag as string).toUpperCase()}]`, 'system');
                    }}
                    className={`text-[9px] uppercase tracking-wider px-3 py-1.5 rounded font-mono border transition-all ${
                      filterTag === tag 
                        ? 'text-white border-white/30 bg-white/5 font-semibold' 
                        : 'text-white/40 border-white/5 hover:border-white/15 hover:text-white bg-black/20'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* PROJECTS GRID */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
              
              {filteredProjects.map((proj) => {
                const currentAccentColor = accentTextColors[proj.accent] || accentTextColors[accentColor];
                const currentAccentBorder = accentBorderColors[proj.accent] || accentBorderColors[accentColor];
                const currentAccentBg = accentBgColors[proj.accent] || accentBgColors[accentColor];

                return (
                  <div 
                    key={proj.id} 
                    className={`group relative border rounded-xl overflow-hidden bg-[#0c0c0c]/80 hover:bg-[#0f0f0f] p-6 flex flex-col justify-between min-h-[220px] transition-all duration-300 ${currentAccentBorder}`}
                    style={{
                      boxShadow: '0 4px 30px rgba(0, 0, 0, 0.4)'
                    }}
                  >
                    {/* Index tag top right */}
                    <div className="absolute top-4 right-4 font-mono text-[10px] text-white/20 group-hover:text-white/60 transition-colors">
                      [ {proj.index} ]
                    </div>

                    <div>
                      {/* Accent Color Band */}
                      <div className={`w-10 h-0.5 mb-6 transition-all duration-500 group-hover:w-20 ${currentAccentBg}`}></div>
                      
                      {/* Project Title */}
                      <h3 className="text-lg font-bold text-white group-hover:text-white mb-2 tracking-wide flex items-center gap-1.5">
                        {proj.title}
                      </h3>
                      
                      {/* Description */}
                      <p className="text-xs text-white/50 group-hover:text-white/70 leading-relaxed font-light mb-6">
                        {proj.description}
                      </p>
                    </div>

                    <div>
                      {/* Tags & Action Row */}
                      <div className="flex flex-wrap gap-1.5 mb-4">
                        {proj.tags.map((tag, i) => (
                          <span 
                            key={i} 
                            className="text-[8px] font-mono tracking-widest px-2 py-0.5 bg-white/5 rounded text-white/60 uppercase"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-white/5">
                        
                        {/* Project Link */}
                        <a 
                          href={proj.link} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          onClick={() => {
                            triggerSynth('click');
                            pushLog(`LAUNCH_URL: Redirecting to ${proj.title} repository`, 'action');
                          }}
                          className="text-[9px] font-mono uppercase tracking-wider flex items-center gap-1 text-white/40 hover:text-white hover:underline transition-colors"
                        >
                          <ExternalLink size={10} /> Launch Hub
                        </a>

                        {/* Quick Action Editor Controls */}
                        <div className="flex gap-2">
                          <button
                            onClick={() => startEdit(proj)}
                            className="p-1 rounded bg-white/5 hover:bg-white/10 text-white/40 hover:text-white transition-all"
                            title="Edit Proyek Ini"
                          >
                            <Edit3 size={11} />
                          </button>
                          <button
                            onClick={() => handleDeleteProject(proj.id, proj.title)}
                            className="p-1 rounded bg-white/5 hover:bg-red-950/40 text-white/40 hover:text-red-400 transition-all border border-transparent hover:border-red-500/35"
                            title="Hapus Proyek"
                          >
                            <Trash2 size={11} />
                          </button>
                        </div>

                      </div>
                    </div>

                  </div>
                );
              })}

              {/* EMPTY PLACEHOLDER CARD */}
              {filteredProjects.length === 0 && (
                <div className="col-span-full border border-dashed border-white/10 rounded-xl p-12 text-center flex flex-col items-center justify-center bg-black/10">
                  <Database size={24} className="text-white/20 mb-3 animate-bounce" />
                  <span className="text-xs font-mono text-white/40 uppercase tracking-widest">Tidak ada proyek yang sesuai dengan filter</span>
                  <button 
                    onClick={() => setFilterTag('All')}
                    className="mt-4 text-[10px] font-mono tracking-wider border border-white/10 rounded px-3 py-1.5 hover:bg-white/5 text-white/70"
                  >
                    Reset Filter
                  </button>
                </div>
              )}

            </div>

            {/* INTERACTIVE CONTROLS ENGINE (Yang akan diatur sendiri) */}
            <div className="border border-white/10 rounded-lg bg-black/40 p-6 flex flex-col md:flex-row items-center justify-between gap-6 relative">
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Settings size={14} style={{ color: currentThemeHex }} /> Control Panel Portofolio
                </h4>
                <p className="text-xs text-white/40 max-w-lg font-light">
                  Anda dapat menyetel sendiri proyek di atas secara instan! Tambahkan proyek baru, edit isi kartu, atau salin file backup konfigurasi Anda di sini.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    triggerSynth('click');
                    setEditingProject(null);
                    setFormData({ title: '', description: '', tags: [], link: '', accent: 'cyan' });
                    setFormTagsString('');
                    setShowConfigModal(true);
                    pushLog("TERMINAL INPUT: Open Project Creator", "action");
                  }}
                  className="text-[9px] uppercase font-mono tracking-widest bg-white text-black font-semibold hover:bg-white/95 px-4 py-2 rounded transition-all flex items-center gap-1.5 shadow-lg shadow-white/5 cursor-pointer"
                >
                  <Plus size={12} /> Tambah Project
                </button>

                <button
                  onClick={exportConfig}
                  className="text-[9px] uppercase font-mono tracking-widest border border-white/10 hover:border-white/25 hover:bg-white/5 text-white/70 px-3 py-2 rounded transition-all flex items-center gap-1.5 cursor-pointer"
                  title="Salin JSON konfigurasi saat ini"
                >
                  Export Backup
                </button>

                <button
                  onClick={importConfig}
                  className="text-[9px] uppercase font-mono tracking-widest border border-white/10 hover:border-white/25 hover:bg-white/5 text-white/70 px-3 py-2 rounded transition-all flex items-center gap-1.5 cursor-pointer"
                  title="Impor daftar proyek dari cadangan JSON"
                >
                  Import Backup
                </button>

                <button
                  onClick={handleResetProjects}
                  className="text-[9px] uppercase font-mono tracking-widest border border-red-500/10 hover:border-red-500/30 text-red-400 hover:bg-red-500/5 px-3 py-2 rounded transition-all flex items-center gap-1"
                >
                  Reset Default
                </button>
              </div>
            </div>

          </section>

          {/* PROJECT CREATOR MODAL OVERLAY */}
          {showConfigModal && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
              
              <div 
                className="w-full max-w-lg border border-white/15 bg-[#0a0a0a] rounded-xl overflow-hidden p-6 relative animate-fadeIn"
                style={{
                  boxShadow: `0 10px 40px rgba(0,0,0,0.8), 0 0 15px ${currentThemeHex}15`
                }}
              >
                {/* Header modal */}
                <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
                  <div className="flex items-center gap-2">
                    <Sliders size={15} style={{ color: currentThemeHex }} />
                    <span className="text-xs uppercase font-mono tracking-widest font-bold text-white">
                      {editingProject ? 'Sistem Edit Kartu Proyek' : 'Konfigurator Proyek Baru'}
                    </span>
                  </div>
                  <button 
                    onClick={() => {
                      triggerSynth('click');
                      setShowConfigModal(false);
                      setEditingProject(null);
                    }}
                    className="p-1 rounded text-white/40 hover:text-white transition-all hover:bg-white/5"
                  >
                    <X size={15} />
                  </button>
                </div>

                <form onSubmit={handleSaveProject} className="space-y-4">
                  
                  {/* Title field */}
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Judul Proyek *</label>
                    <input 
                      type="text" 
                      required
                      value={formData.title || ''}
                      onChange={(e) => setFormData(p => ({ ...p, title: e.target.value }))}
                      placeholder="Contoh: Neural Web Interface" 
                      className="w-full bg-black border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>

                  {/* Description field */}
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Deskripsi Proyek *</label>
                    <textarea 
                      required
                      rows={3}
                      value={formData.description || ''}
                      onChange={(e) => setFormData(p => ({ ...p, description: e.target.value }))}
                      placeholder="Jelaskan ringkasan fungsionalitas dan stack teknis proyek." 
                      className="w-full bg-black border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                    />
                  </div>

                  {/* Link field */}
                  <div>
                    <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Tautan URL / Github Repository</label>
                    <input 
                      type="url" 
                      value={formData.link || ''}
                      onChange={(e) => setFormData(p => ({ ...p, link: e.target.value }))}
                      placeholder="https://github.com/AkbarBatagore" 
                      className="w-full bg-black border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                  </div>

                  {/* Accent design & Tags side-by-side */}
                  <div className="grid grid-cols-2 gap-4">
                    
                    {/* Tags input */}
                    <div>
                      <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Tags (Pisahkan koma)</label>
                      <input 
                        type="text" 
                        value={formTagsString}
                        onChange={(e) => setFormTagsString(e.target.value)}
                        placeholder="React, Rust, UI" 
                        className="w-full bg-black border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                      />
                    </div>

                    {/* Accent selection */}
                    <div>
                      <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Warna Aksen Kartu</label>
                      <select
                        value={formData.accent || 'cyan'}
                        onChange={(e) => setFormData(p => ({ ...p, accent: e.target.value as any }))}
                        className="w-full bg-black border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                      >
                        <option value="cyan">Cyan (Sian)</option>
                        <option value="purple">Purple (Fuchsia)</option>
                        <option value="emerald">Emerald (Hijau)</option>
                        <option value="amber">Amber (Kuning)</option>
                        <option value="rose">Rose (Merah)</option>
                      </select>
                    </div>

                  </div>

                  {/* Submit controls */}
                  <div className="pt-4 border-t border-white/10 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        triggerSynth('click');
                        setShowConfigModal(false);
                        setEditingProject(null);
                      }}
                      className="text-[10px] font-mono uppercase tracking-wider px-4 py-2 border border-white/10 rounded text-white/50 hover:text-white"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="text-[10px] font-mono uppercase tracking-wider px-5 py-2 rounded bg-white text-black font-semibold hover:bg-white/90 transition-colors flex items-center gap-1"
                    >
                      <Check size={11} /> Simpan Kartu
                    </button>
                  </div>

                </form>

              </div>

            </div>
          )}

          {/* SECTION: SKILLS MATRIX */}
          <section id="skills" className="p-6 md:p-12 border-b border-white/10 relative">
            
            <div className="absolute top-0 left-0 w-32 h-32 bg-fuchsia-500/[0.01] border-b border-r border-white/5 pointer-events-none"></div>

            <div className="mb-10">
              <div className="flex items-center gap-2 mb-2">
                <Code size={12} style={{ color: currentThemeHex }} />
                <span className="text-[10px] tracking-[0.4em] uppercase font-bold text-white/40">PROFICIENCY GRID</span>
              </div>
              <h2 className="text-3xl font-light tracking-wide text-white">
                Spesialisasi <span className="font-bold">Sistem</span>
              </h2>
            </div>

            {/* SKILLS CONTAINER */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {SKILLS.map((skill, index) => (
                <div 
                  key={index}
                  className="border border-white/5 bg-white/[0.01] hover:bg-white/[0.03] rounded-lg p-5 transition-all duration-300 relative group overflow-hidden"
                  onMouseEnter={() => triggerSynth('hover')}
                >
                  <div className="absolute top-0 left-0 h-[2px] w-0 group-hover:w-full transition-all duration-500" style={{ backgroundColor: currentThemeHex }}></div>

                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs font-mono font-semibold tracking-wider text-white group-hover:text-white transition-colors">{skill.name}</span>
                    <span className="text-[10px] font-mono text-white/30 group-hover:text-white/80 transition-colors" style={{ color: currentThemeHex }}>{skill.level}%</span>
                  </div>

                  {/* Custom animated neon loader bar */}
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all duration-1000 ease-out"
                      style={{ 
                        width: `${skill.level}%`, 
                        backgroundColor: currentThemeHex,
                        boxShadow: `0 0 8px ${currentThemeHex}aa`
                      }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center mt-3 text-[8px] font-mono text-white/20">
                    <span>SYS_ALLOC: ACTIVE</span>
                    <span>TYPE // {skill.category.toUpperCase()}</span>
                  </div>

                </div>
              ))}

            </div>

          </section>

          {/* SECTION: CONTACT INTERFACE */}
          <section id="contact" className="p-6 md:p-12 relative flex-1 flex flex-col justify-between min-h-[500px]">
            
            <div className="absolute bottom-0 right-0 w-44 h-44 bg-cyan-500/[0.01] border-t border-l border-white/5 pointer-events-none"></div>

            <div className="mb-8">
              <div className="flex items-center gap-2 mb-2">
                <Send size={12} style={{ color: currentThemeHex }} />
                <span className="text-[10px] tracking-[0.4em] uppercase font-bold text-white/40">SECURE COMMS INTERFACE</span>
              </div>
              <h2 className="text-3xl font-light tracking-wide text-white">
                Koneksi <span className="font-bold">Sistem</span>
              </h2>
              <p className="text-xs text-white/40 mt-3 max-w-md font-light leading-relaxed">
                Kirim pesan terenkripsi langsung ke Reonzy Akbar. Saluran tanggapan sistem dijamin aktif dalam waktu 24 jam operasional bumi.
              </p>
            </div>

            {/* CONTACT FORM */}
            <form onSubmit={handleContactSubmit} className="space-y-4 max-w-xl mb-12">
              
              {/* Row for Name and Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Identitas Pemanggil *</label>
                  <input 
                    type="text" 
                    required
                    value={contactForm.name}
                    onChange={(e) => setContactForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Nama / Korporasi" 
                    className="w-full bg-black/60 border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Alamat Email *</label>
                  <input 
                    type="email" 
                    required
                    value={contactForm.email}
                    onChange={(e) => setContactForm(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="nama@domain.com" 
                    className="w-full bg-black/60 border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>

              </div>

              {/* Subject */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Subjek Node</label>
                <input 
                  type="text" 
                  value={contactForm.subject}
                  onChange={(e) => setContactForm(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="Inquiry Proyek / Kolaborasi" 
                  className="w-full bg-black/60 border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Message Payload */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-wider text-white/40 mb-1.5">Pesan Payload *</label>
                <textarea 
                  required
                  rows={4}
                  value={contactForm.message}
                  onChange={(e) => setContactForm(prev => ({ ...prev, message: e.target.value }))}
                  placeholder="Ketikkan pesan detail Anda di sini..." 
                  className="w-full bg-black/60 border border-white/10 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                />
              </div>

              {/* Submit Transmit Button */}
              <div className="flex items-center gap-4">
                <button
                  type="submit"
                  disabled={isSending}
                  className="text-[10px] uppercase font-mono tracking-widest bg-white text-black font-semibold hover:bg-white/90 disabled:bg-white/50 disabled:text-black/50 px-5 py-2.5 rounded transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isSending ? (
                    <>
                      <RefreshCw size={11} className="animate-spin" /> MENTRANSMISIKAN...
                    </>
                  ) : (
                    <>
                      <Send size={11} /> TRANSMIT_PESAN
                    </>
                  )}
                </button>

                {sendSuccess && (
                  <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1.5 animate-pulse">
                    <Check size={12} /> Pesan Berhasil Ditransmisikan ke Server Email!
                  </div>
                )}
              </div>

            </form>

            {/* STATUS FOOTER SYSTEM */}
            <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 text-center sm:text-left">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
                <span className="text-[10px] uppercase tracking-widest text-white/40 font-mono">
                  All Systems Fully Functional // Ping Stable
                </span>
              </div>
              <div className="text-[10px] uppercase tracking-widest text-white/20 font-mono">
                © {new Date().getFullYear()} REONZY AKBAR / CRAFTED WITH REACT & TAILWIND V4
              </div>
            </div>

          </section>

        </main>

      </div>

    </div>
  );
}
